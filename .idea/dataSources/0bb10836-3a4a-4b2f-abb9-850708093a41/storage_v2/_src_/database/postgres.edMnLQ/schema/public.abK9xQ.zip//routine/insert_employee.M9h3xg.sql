create procedure insert_employee(IN first_name character varying, IN last_name character varying, IN email character varying, IN phone character varying)
    language plpgsql
as
$$
BEGIN
    INSERT INTO employees (first_name, last_name, email, phone) VALUES (first_name, last_name, email, phone);
end;
$$;

alter procedure insert_employee(varchar, varchar, varchar, varchar) owner to postgres;

